// Package ghapi provides functions for interacting with the GitHub API (GraphQL and REST).
package ghapi

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"os/exec"
	"strings"
	"sync"
	"time"

	"github.com/cvega/gh-github-stats/internal/output"
	"github.com/cvega/gh-github-stats/internal/state"
	"github.com/pterm/pterm"
)

// Package types supported by GitHub.
const (
	PackageTypeContainer = "container"
	PackageTypeNPM       = "npm"
	PackageTypeMaven     = "maven"
	PackageTypeRubyGems  = "rubygems"
	PackageTypeNuGet     = "nuget"
	PackageTypeDocker    = "docker"
)

// Constants for configuration
const (
	MaxConcurrentPackageFetches = 2
	PackageTypeCycleInterval    = 500 * time.Millisecond
	DoneMessageDisplayTime      = 1200 * time.Millisecond
	maxRetries                  = 5
	initialBackoff              = 1 * time.Second
)

// SupportedPackageTypes lists all supported package types for the GitHub Packages API.
var SupportedPackageTypes = []string{
	PackageTypeContainer,
	PackageTypeNPM,
	PackageTypeMaven,
	PackageTypeRubyGems,
	PackageTypeNuGet,
	PackageTypeDocker,
}

// GraphQLPageFunc is a callback that should return the endCursor and hasNextPage from the current response.
type GraphQLPageFunc func(data map[string]interface{}) (string, bool)

// PackageResponse is the REST API response structure for a package.
// This struct matches the GitHub Packages API response format.
type PackageResponse struct {
	Name       string `json:"name"`         // Package name
	Type       string `json:"package_type"` // Package type (npm, maven, etc.)
	Visibility string `json:"visibility"`   // Package visibility (public, private)
	CreatedAt  string `json:"created_at"`   // ISO 8601 timestamp
	UpdatedAt  string `json:"updated_at"`   // ISO 8601 timestamp
	Repository struct {
		Name string `json:"name"` // Associated repository name (empty if unassigned)
	} `json:"repository"`
	VersionCount *int `json:"version_count,omitempty"` // Number of versions (nil if not available from API)
}

// RateLimitResponse represents the GitHub API rate limit response.
// This struct matches the GitHub API rate limit endpoint response format.
type RateLimitResponse struct {
	Resources struct {
		Core struct {
			Limit     int64 `json:"limit"`     // Total API calls allowed per hour
			Remaining int64 `json:"remaining"` // API calls remaining in current hour
			Reset     int64 `json:"reset"`     // Unix timestamp when rate limit resets
		} `json:"core"`
	} `json:"resources"`
}

// RunGraphQLPaginated executes a paginated GraphQL query using the GitHub CLI,
// accumulating all pages of results. The pageFunc callback extracts pagination info
// from each response. Returns a slice of all page results.
func RunGraphQLPaginated(query string, variables map[string]interface{}, pageFunc GraphQLPageFunc) ([]map[string]interface{}, error) {
	var allPages []map[string]interface{}
	var endCursor string
	pageCount := 0

	// Update rate limit info at the start
	UpdateRateLimitInfo()

	for {
		pageCount++
		args := []string{"api", "graphql"}
		args = append(args, "-f", fmt.Sprintf("query=%s", query))

		// Add variables as individual -F flags
		for k, v := range variables {
			args = append(args, "-F", fmt.Sprintf("%s=%v", k, v))
		}

		if endCursor != "" {
			args = append(args, "-F", fmt.Sprintf("endCursor=%s", endCursor))
		}

		cmd := exec.Command("gh", args...)
		cmd.Env = os.Environ()
		var stdout, stderr bytes.Buffer
		cmd.Stdout = &stdout
		cmd.Stderr = &stderr

		if err := cmd.Run(); err != nil {
			return nil, fmt.Errorf("GraphQL API call failed (page %d): %w\nstderr: %s", pageCount, err, stderr.String())
		}

		state.Get().IncrementAPICalls()

		// Update rate limit info every 50 API calls (less frequent)
		if pageCount%50 == 0 {
			UpdateRateLimitInfo()
			state.Get().PrintRateLimit()
		}

		var result map[string]interface{}
		if err := json.Unmarshal(stdout.Bytes(), &result); err != nil {
			return nil, fmt.Errorf("failed to parse GraphQL response (page %d): %w\nresponse: %s", pageCount, err, stdout.String())
		}

		// Check for GraphQL errors
		if errors, ok := result["errors"].([]interface{}); ok && len(errors) > 0 {
			return nil, fmt.Errorf("GraphQL errors on page %d: %v", pageCount, errors)
		}

		allPages = append(allPages, result)

		nextCursor, hasNextPage := pageFunc(result)
		if !hasNextPage {
			break
		}
		endCursor = nextCursor
	}

	return allPages, nil
}

// RunRESTPaginated calls the GitHub REST API with pagination and retries on server errors.
// Returns all results as a slice of PackageResponse. Retries up to maxRetries on 5xx errors.
func RunRESTPaginated(endpoint string, verbose bool) ([]PackageResponse, error) {
	// Update rate limit info at the start
	UpdateRateLimitInfo()

	var lastErr error
	for attempt := 0; attempt < maxRetries; attempt++ {
		// Use --include to get headers in the response
		cmd := exec.Command("gh", "api", "--paginate", "--include", endpoint)
		cmd.Env = os.Environ()
		var stdout, stderr bytes.Buffer
		cmd.Stdout = &stdout
		cmd.Stderr = &stderr

		if err := cmd.Run(); err == nil {
			state.Get().IncrementAPICalls()

			// Update rate limit info after successful call (but don't print)
			UpdateRateLimitInfo()

			// Parse the response which now includes headers
			response := stdout.String()
			headers, body := extractHeadersAndBody(response)

			// Print headers for debugging if verbose is enabled
			if verbose && len(headers) > 0 {
				pterm.Info.Printf("Headers for %s:\n", endpoint)
				for name, value := range headers {
					pterm.Info.Printf("  %s: %s\n", name, value)
				}
			}

			// Try to parse body as a JSON array first
			var arrayResults []PackageResponse
			if err := json.Unmarshal([]byte(body), &arrayResults); err == nil {
				return arrayResults, nil
			}

			// Fallback: Split the body by newlines and parse each line as JSON
			lines := strings.Split(strings.TrimSpace(body), "\n")
			var results []PackageResponse
			for i, line := range lines {
				if line == "" {
					continue
				}
				var result PackageResponse
				if err := json.Unmarshal([]byte(line), &result); err != nil {
					return nil, fmt.Errorf("failed to parse REST response line %d: %w\nline: %s", i+1, err, line)
				}
				results = append(results, result)
			}

			return results, nil
		} else {
			lastErr = fmt.Errorf("REST API call failed for %s: %w\nstderr: %s", endpoint, err, stderr.String())
			// Check for 5xx or "Server Error" in stderr
			if strings.Contains(stderr.String(), "Server Error") || strings.Contains(stderr.String(), "502") {
				backoff := time.Duration(math.Pow(2, float64(attempt))) * initialBackoff
				pterm.Warning.Printf("%s, retrying in %v (attempt %d/%d)\n", endpoint, backoff, attempt+1, maxRetries)
				time.Sleep(backoff)
				continue
			} else {
				// Non-retryable error
				return nil, lastErr
			}
		}
	}
	return nil, fmt.Errorf("all retries failed: %w", lastErr)
}

// extractHeadersAndBody parses the response from GitHub CLI when using --include flag.
// Returns headers map and body string. The --include flag outputs headers followed by a blank line, then the body.
func extractHeadersAndBody(response string) (map[string]string, string) {
	headers := make(map[string]string)

	// Split response into lines
	lines := strings.Split(response, "\n")

	// Find the blank line that separates headers from body
	bodyStart := -1
	for i, line := range lines {
		if strings.TrimSpace(line) == "" {
			bodyStart = i + 1
			break
		}
	}

	// If no blank line found, assume entire response is body
	if bodyStart == -1 {
		return headers, response
	}

	// Parse headers (lines before the blank line)
	for i := 0; i < bodyStart-1; i++ {
		line := strings.TrimSpace(lines[i])
		if line == "" {
			continue
		}

		// Parse header in format "Name: Value"
		if colonIndex := strings.Index(line, ":"); colonIndex > 0 {
			name := strings.TrimSpace(line[:colonIndex])
			value := strings.TrimSpace(line[colonIndex+1:])
			headers[name] = value
		}
	}

	// Extract body (lines after the blank line)
	body := strings.Join(lines[bodyStart:], "\n")

	return headers, body
}

// startPackageProgressBar cycles the progress bar title through remaining package types until done is closed.
// Intended to be run as a goroutine. WaitGroup is used for synchronization.
func startPackageProgressBar(progress *pterm.ProgressbarPrinter, done <-chan struct{}, completed <-chan string, wg *sync.WaitGroup) {
	defer wg.Done()

	// Track which package types have been completed
	completedTypes := make(map[string]bool)
	remainingTypes := make([]string, len(SupportedPackageTypes))
	copy(remainingTypes, SupportedPackageTypes)

	// Simple counter for cycling through remaining types
	counter := 0

	for {
		select {
		case <-done:
			progress.UpdateTitle("Fetching packages done")
			time.Sleep(DoneMessageDisplayTime)
			progress.Stop()
			pterm.Info.Println("Fetching packages done")
			return
		case completedType := <-completed:
			// Mark this package type as completed
			completedTypes[completedType] = true

			// Update remaining types list
			remainingTypes = remainingTypes[:0]
			for _, pkgType := range SupportedPackageTypes {
				if !completedTypes[pkgType] {
					remainingTypes = append(remainingTypes, pkgType)
				}
			}
		default:
			// Show remaining package types in rotation
			if len(remainingTypes) > 0 {
				// Use a simple counter to cycle through remaining types
				index := counter % len(remainingTypes)
				pkgType := remainingTypes[index]
				progress.UpdateTitle(fmt.Sprintf("Fetching %s packages... (%d remaining)", pkgType, len(remainingTypes)))
				counter++
			} else {
				progress.UpdateTitle("Processing package data...")
			}
			time.Sleep(PackageTypeCycleInterval)
		}
	}
}

// fetchPackagesForType fetches all packages of a given type for an org using the REST API.
func fetchPackagesForType(org, pkgType string, verbose bool) ([]PackageResponse, error) {
	endpoint := fmt.Sprintf("/orgs/%s/packages?package_type=%s", org, pkgType)
	return RunRESTPaginated(endpoint, verbose)
}

// convertToPackageData converts PackageResponse to PackageData for CSV output.
func convertToPackageData(org string, results []PackageResponse) []output.PackageData {
	var packageData []output.PackageData
	for _, pkg := range results {
		repoName := pkg.Repository.Name
		if repoName == "" {
			repoName = "unassigned" // Packages not associated with a specific repository
		}

		packageData = append(packageData, output.PackageData{
			Org:          org,
			Repo:         repoName,
			PackageName:  pkg.Name,
			PackageType:  pkg.Type,
			Visibility:   pkg.Visibility,
			CreatedAt:    pkg.CreatedAt,
			UpdatedAt:    pkg.UpdatedAt,
			VersionCount: pkg.VersionCount,
		})
	}
	return packageData
}

// GetOrgPackageDataWithResume fetches package data for each repository in an org,
// with support for resuming from existing package data. Returns both package counts and version counts.
// If existingCounts is provided and not empty, it will be used instead of fetching new data.
// If packageFilePath is provided, package data will be written to that file.
func GetOrgPackageDataWithResume(org string, progress *pterm.ProgressbarPrinter, existingCounts map[string]output.PackageCounts, packageFilePath string, verbose bool) (map[string]output.PackageCounts, error) {
	// If we have existing counts and they're not empty, use them
	if len(existingCounts) > 0 {
		if progress != nil {
			progress.UpdateTitle("Using existing package data")
			for i := 0; i < len(SupportedPackageTypes); i++ {
				progress.Increment()
			}
			progress.Stop()
		}
		pterm.Info.Printf("Using existing package data for %s (%d repositories)\n", org, len(existingCounts))
		return existingCounts, nil
	}

	repoPackages := make(map[string]map[string]output.PackageData)
	var countsMu sync.Mutex
	var allPackageData []output.PackageData
	var packageDataMu sync.Mutex

	done := make(chan struct{})
	completed := make(chan string, len(SupportedPackageTypes)) // Channel to track completed package types
	var cyclingWG sync.WaitGroup
	if progress != nil {
		cyclingWG.Add(1)
		go startPackageProgressBar(progress, done, completed, &cyclingWG)
	}

	var wg sync.WaitGroup
	semaphore := make(chan struct{}, MaxConcurrentPackageFetches)

	for _, pkgType := range SupportedPackageTypes {
		wg.Add(1)
		go func(pkgType string) {
			defer wg.Done()
			semaphore <- struct{}{}
			defer func() { <-semaphore }()

			results, err := fetchPackagesForType(org, pkgType, verbose)
			if err == nil {
				countsMu.Lock()
				// Aggregate packages with full data
				for _, pkg := range results {
					repoName := pkg.Repository.Name
					if repoName == "" {
						repoName = "unassigned" // Packages not associated with a specific repository
					}

					if _, ok := repoPackages[repoName]; !ok {
						repoPackages[repoName] = make(map[string]output.PackageData)
					}
					repoPackages[repoName][pkg.Name] = output.PackageData{
						Org:          org,
						Repo:         repoName,
						PackageName:  pkg.Name,
						PackageType:  pkg.Type,
						Visibility:   pkg.Visibility,
						CreatedAt:    pkg.CreatedAt,
						UpdatedAt:    pkg.UpdatedAt,
						VersionCount: pkg.VersionCount,
					}
				}
				countsMu.Unlock()

				// Convert to PackageData for CSV output
				if packageFilePath != "" {
					packageDataMu.Lock()
					allPackageData = append(allPackageData, convertToPackageData(org, results)...)
					packageDataMu.Unlock()
				}

				if progress != nil {
					progress.Increment()
				}

				// Notify that this package type is completed
				select {
				case completed <- pkgType:
				default:
					// Channel might be full, but that's okay
				}
			} else {
				pterm.Warning.Printf("Failed to fetch %s packages for %s: %v\n", pkgType, org, err)
				// Even if failed, mark as completed to remove from progress bar
				select {
				case completed <- pkgType:
				default:
					// Channel might be full, but that's okay
				}
			}
		}(pkgType)
	}

	wg.Wait()
	close(done)
	cyclingWG.Wait()

	// Write package data to CSV if file path is provided
	if packageFilePath != "" && len(allPackageData) > 0 {
		if err := output.WritePackageCSV(org, packageFilePath, allPackageData); err != nil {
			pterm.Warning.Printf("Failed to write package data to %s: %v\n", packageFilePath, err)
		} else {
			pterm.Info.Printf("Package data written to %s (%d packages)\n", packageFilePath, len(allPackageData))
		}
	}

	// Convert to PackageCounts
	counts := make(map[string]output.PackageCounts)
	for repo, pkgs := range repoPackages {
		packageCount := len(pkgs)
		versionCount := 0

		// Sum up version counts for all packages in this repository
		for _, pkg := range pkgs {
			if pkg.VersionCount != nil {
				versionCount += *pkg.VersionCount
			}
		}

		counts[repo] = output.PackageCounts{
			PackageCount:    packageCount,
			PackageVersions: versionCount,
		}
	}
	return counts, nil
}

// GetRateLimit fetches the current GitHub API rate limit information
func GetRateLimit() (*RateLimitResponse, error) {
	cmd := exec.Command("gh", "api", "rate_limit")
	cmd.Env = os.Environ()
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	if err := cmd.Run(); err != nil {
		return nil, fmt.Errorf("failed to fetch rate limit: %w\nstderr: %s", err, stderr.String())
	}

	var response RateLimitResponse
	if err := json.Unmarshal(stdout.Bytes(), &response); err != nil {
		return nil, fmt.Errorf("failed to parse rate limit response: %w", err)
	}

	return &response, nil
}

// UpdateRateLimitInfo fetches and updates the current rate limit information
func UpdateRateLimitInfo() {
	rateLimit, err := GetRateLimit()
	if err != nil {
		// Don't fail the entire operation if we can't get rate limit info
		return
	}

	// Convert Unix timestamp to time.Time
	resetTime := time.Unix(rateLimit.Resources.Core.Reset, 0)

	state.Get().UpdateRateLimit(
		rateLimit.Resources.Core.Limit,
		rateLimit.Resources.Core.Remaining,
		resetTime,
	)
}
