// Package state provides global state tracking for statistics collection progress.
package state

import (
	"fmt"
	"sync/atomic"
	"time"

	"github.com/pterm/pterm"
)

// RateLimitInfo holds GitHub API rate limit information
type RateLimitInfo struct {
	Limit     int64
	Remaining int64
	Reset     time.Time
}

// Status tracks the progress and API call counts for the current run.
type Status struct {
	repoTotal   int64
	repoDone    int64
	apiCalls    int64
	rateLimit   RateLimitInfo
	rateLimitMu atomic.Value // atomic.Value to store *RateLimitInfo
}

var global = &Status{}

// Get returns the global Status instance for tracking progress and API calls.
func Get() *Status {
	return global
}

// PrintRepo prints the status of a processed repository (success or warning) and increments the done count.
func (s *Status) PrintRepo(repoName string, success bool) {
	if success {
		pterm.Success.Printf("✓ %s\n", repoName)
	} else {
		pterm.Warning.Printf("⚠ %s\n", repoName)
	}
	atomic.AddInt64(&s.repoDone, 1)
}

// PrintOrg prints the organization being processed.
func (s *Status) PrintOrg(orgName string) {
	pterm.Info.Printf("Processing organization: %s\n", orgName)
}

// MarkDone prints a final summary of the run, including total repos and API calls.
func (s *Status) MarkDone() {
	repoDone := atomic.LoadInt64(&s.repoDone)
	repoTotal := atomic.LoadInt64(&s.repoTotal)
	apiCalls := atomic.LoadInt64(&s.apiCalls)

	status := fmt.Sprintf("Complete! Processed %d/%d repos | Total API calls: %d",
		repoDone, repoTotal, apiCalls)
	pterm.Success.Printf("✓ %s\n", status)
}

// AddRepos increments the total repository count (thread-safe).
func (s *Status) AddRepos(n int) {
	atomic.AddInt64(&s.repoTotal, int64(n))
}

// IncrementAPICalls increments the API call count (thread-safe).
func (s *Status) IncrementAPICalls() {
	atomic.AddInt64(&s.apiCalls, 1)
}

// UpdateRateLimit updates the rate limit information (thread-safe).
func (s *Status) UpdateRateLimit(limit, remaining int64, reset time.Time) {
	rateLimit := &RateLimitInfo{
		Limit:     limit,
		Remaining: remaining,
		Reset:     reset,
	}
	s.rateLimitMu.Store(rateLimit)
}

// GetRateLimit returns the current rate limit information (thread-safe).
func (s *Status) GetRateLimit() RateLimitInfo {
	if val := s.rateLimitMu.Load(); val != nil {
		if rateLimit, ok := val.(*RateLimitInfo); ok {
			return *rateLimit
		}
	}
	return RateLimitInfo{}
}

// PrintRateLimit prints the current rate limit status.
func (s *Status) PrintRateLimit() {
	rateLimit := s.GetRateLimit()
	if rateLimit.Limit > 0 {
		used := rateLimit.Limit - rateLimit.Remaining
		pterm.Info.Printf("%d/%d calls used | %d remaining | resets at: %s\n",
			used, rateLimit.Limit, rateLimit.Remaining, rateLimit.Reset.Format("15:04:05"))
	}
}
