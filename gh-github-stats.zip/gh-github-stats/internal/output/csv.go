// Package output provides CSV output functionality for repository statistics and package data.
package output

import (
	"encoding/csv"
	"fmt"
	"os"
	"strconv"
	"strings"
)

const (
	// CSV field counts for validation
	repoStatsFieldCount = 24 // Number of fields in repository statistics CSV (increased by 1)
)

// RepoStats holds all statistics for a single repository, as written to the CSV output.
// Matches the fields fetched in the GraphQL query.
type RepoStats struct {
	Org               string
	Name              string
	URL               string
	IsFork            bool
	IsArchived        bool
	SizeMB            int
	HasWiki           bool
	CreatedAt         string
	UpdatedAt         string
	PushedAt          string
	Collaborators     int
	Branches          int
	Tags              int
	ProtectedBranches int
	Issues            int
	PRs               int
	Milestones        int
	Releases          int
	Projects          int
	Discussions       int
	CommitComments    int
	IssueEvents       int // Added: Number of issue events
	Packages          int
	PackageVersions   int // Total sum of package version counts for this repository
}

// PackageData holds package information for a repository.
type PackageData struct {
	Org          string
	Repo         string
	PackageName  string
	PackageType  string
	Visibility   string
	CreatedAt    string
	UpdatedAt    string
	VersionCount *int // Number of versions (nil if not available from API)
}

// PackageCounts holds both package count and version count for a repository.
type PackageCounts struct {
	PackageCount    int // Total number of packages in the repository
	PackageVersions int // Total sum of all package version counts
}

// repoStatsHeader returns the CSV header for repository statistics
func repoStatsHeader() []string {
	return []string{
		"org", "repo", "url", "isFork", "isArchived", "sizeMB", "hasWiki", "createdAt", "updatedAt", "pushedAt",
		"collaborators", "branches", "tags", "protectedBranches", "issues", "pullRequests", "milestones",
		"releases", "projects", "discussions", "commitComments", "issueEvents", "packages", "packageVersions",
	}
}

// repoStatsToRow converts a RepoStats struct to a CSV row
func repoStatsToRow(r RepoStats) []string {
	row := make([]string, repoStatsFieldCount)
	row[0] = r.Org
	row[1] = r.Name
	row[2] = r.URL
	row[3] = boolStr(r.IsFork)
	row[4] = boolStr(r.IsArchived)
	row[5] = strconv.Itoa(r.SizeMB)
	row[6] = boolStr(r.HasWiki)
	row[7] = r.CreatedAt
	row[8] = r.UpdatedAt
	row[9] = r.PushedAt
	row[10] = strconv.Itoa(r.Collaborators)
	row[11] = strconv.Itoa(r.Branches)
	row[12] = strconv.Itoa(r.Tags)
	row[13] = strconv.Itoa(r.ProtectedBranches)
	row[14] = strconv.Itoa(r.Issues)
	row[15] = strconv.Itoa(r.PRs)
	row[16] = strconv.Itoa(r.Milestones)
	row[17] = strconv.Itoa(r.Releases)
	row[18] = strconv.Itoa(r.Projects)
	row[19] = strconv.Itoa(r.Discussions)
	row[20] = strconv.Itoa(r.CommitComments)
	row[21] = strconv.Itoa(r.IssueEvents)
	row[22] = strconv.Itoa(r.Packages)
	row[23] = strconv.Itoa(r.PackageVersions)
	return row
}

// writeRepoStatsRows writes repository statistics rows to a CSV writer
func writeRepoStatsRows(w *csv.Writer, rows []RepoStats) error {
	for _, r := range rows {
		row := repoStatsToRow(r)
		if err := w.Write(row); err != nil {
			return fmt.Errorf("failed to write row: %w", err)
		}
	}
	return nil
}

// WriteCSV writes the given repository statistics to a CSV file at filePath.
// Each RepoStats struct is written as a row, with a header. Overwrites the file if it exists.
func WriteCSV(filePath string, rows []RepoStats) error {
	file, err := os.Create(filePath)
	if err != nil {
		return fmt.Errorf("failed to create output file: %w", err)
	}
	defer file.Close()

	w := csv.NewWriter(file)
	defer w.Flush()

	// Write header
	if err := w.Write(repoStatsHeader()); err != nil {
		return fmt.Errorf("failed to write header: %w", err)
	}

	// Write rows
	return writeRepoStatsRows(w, rows)
}

// AppendToCSV appends new repository statistics to an existing CSV file.
// If the file doesn't exist, it creates a new one with headers.
func AppendToCSV(filePath string, rows []RepoStats) error {
	// Check if file exists
	fileExists := fileExists(filePath)

	file, err := os.OpenFile(filePath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return fmt.Errorf("failed to open/create output file: %w", err)
	}
	defer file.Close()

	w := csv.NewWriter(file)
	defer w.Flush()

	// Write header only if file is new
	if !fileExists {
		if err := w.Write(repoStatsHeader()); err != nil {
			return fmt.Errorf("failed to write header: %w", err)
		}
	}

	// Write rows
	return writeRepoStatsRows(w, rows)
}

// boolStr returns "TRUE" or "FALSE" for a boolean value, for CSV output.
func boolStr(b bool) string {
	if b {
		return "TRUE"
	}
	return "FALSE"
}

// formatOptionalInt formats an optional int for CSV output.
func formatOptionalInt(val *int) string {
	if val == nil {
		return ""
	}
	return strconv.Itoa(*val)
}

// ReadExistingCSV reads an existing CSV file and returns a map of already processed repositories.
// The map key is "org/repo" and the value is the RepoStats struct.
// Returns an empty map if the file doesn't exist or can't be read.
func ReadExistingCSV(filePath string) (map[string]RepoStats, error) {
	processed := make(map[string]RepoStats)

	// Check if file exists
	if !fileExists(filePath) {
		return processed, nil
	}

	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("failed to open existing CSV file: %w", err)
	}
	defer file.Close()

	reader := csv.NewReader(file)
	records, err := reader.ReadAll()
	if err != nil {
		return nil, fmt.Errorf("failed to read CSV file: %w", err)
	}

	// Skip header row
	if len(records) < 2 {
		return processed, nil
	}

	for i, record := range records[1:] { // Skip header
		if len(record) < repoStatsFieldCount { // Minimum required fields
			continue
		}

		// Parse the record into RepoStats
		stats, err := parseCSVRecord(record)
		if err != nil {
			// Log error but continue processing other records
			fmt.Printf("Warning: skipping invalid record at line %d: %v\n", i+2, err)
			continue
		}

		// Use "org/repo" as the key
		key := fmt.Sprintf("%s/%s", stats.Org, stats.Name)
		processed[key] = stats
	}

	return processed, nil
}

// fileExists checks if a file exists and is not a directory.
func fileExists(filePath string) bool {
	info, err := os.Stat(filePath)
	if os.IsNotExist(err) {
		return false
	}
	return !info.IsDir()
}

// parseCSVRecord parses a CSV record into a RepoStats struct.
func parseCSVRecord(record []string) (RepoStats, error) {
	if len(record) < repoStatsFieldCount {
		return RepoStats{}, fmt.Errorf("insufficient fields in record")
	}

	// Helper function to parse boolean
	parseBool := func(s string) bool {
		return strings.ToUpper(strings.TrimSpace(s)) == "TRUE"
	}

	// Helper function to parse int
	parseInt := func(s string) int {
		s = strings.TrimSpace(s)
		if s == "" {
			return 0
		}
		if i, err := strconv.Atoi(s); err == nil {
			return i
		}
		return 0
	}

	stats := RepoStats{
		Org:               strings.TrimSpace(record[0]),
		Name:              strings.TrimSpace(record[1]),
		URL:               strings.TrimSpace(record[2]),
		IsFork:            parseBool(record[3]),
		IsArchived:        parseBool(record[4]),
		SizeMB:            parseInt(record[5]),
		HasWiki:           parseBool(record[6]),
		CreatedAt:         strings.TrimSpace(record[7]),
		UpdatedAt:         strings.TrimSpace(record[8]),
		PushedAt:          strings.TrimSpace(record[9]),
		Collaborators:     parseInt(record[10]),
		Branches:          parseInt(record[11]),
		Tags:              parseInt(record[12]),
		ProtectedBranches: parseInt(record[13]),
		Issues:            parseInt(record[14]),
		PRs:               parseInt(record[15]),
		Milestones:        parseInt(record[16]),
		Releases:          parseInt(record[17]),
		Projects:          parseInt(record[18]),
		Discussions:       parseInt(record[19]),
		CommitComments:    parseInt(record[20]),
		IssueEvents:       parseInt(record[21]),
		Packages:          parseInt(record[22]),
		PackageVersions:   parseInt(record[23]),
	}

	return stats, nil
}

// WritePackageCSV writes package data to a CSV file for a specific organization.
// Each PackageData struct is written as a row, with a header. Overwrites the file if it exists.
func WritePackageCSV(org, filePath string, packages []PackageData) error {
	file, err := os.Create(filePath)
	if err != nil {
		return fmt.Errorf("failed to create package output file: %w", err)
	}
	defer file.Close()

	w := csv.NewWriter(file)
	defer w.Flush()

	header := []string{
		"org", "repo", "packageName", "packageType", "visibility", "createdAt", "updatedAt", "versionCount",
	}
	if err := w.Write(header); err != nil {
		return fmt.Errorf("failed to write package header: %w", err)
	}

	for _, pkg := range packages {
		row := []string{
			pkg.Org,
			pkg.Repo,
			pkg.PackageName,
			pkg.PackageType,
			pkg.Visibility,
			pkg.CreatedAt,
			pkg.UpdatedAt,
			formatOptionalInt(pkg.VersionCount),
		}
		if err := w.Write(row); err != nil {
			return fmt.Errorf("failed to write package row: %w", err)
		}
	}

	return nil
}

// ReadPackageDataWithVersions reads package data from a CSV file and returns both package counts and version counts.
// The map key is the repository name and the value contains both counts.
// Returns an empty map if the file doesn't exist or can't be read.
func ReadPackageDataWithVersions(filePath string) (map[string]PackageCounts, error) {
	repoPackages := make(map[string]map[string]PackageData)

	// Check if file exists
	if !fileExists(filePath) {
		return make(map[string]PackageCounts), nil
	}

	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("failed to open package CSV file: %w", err)
	}
	defer file.Close()

	reader := csv.NewReader(file)
	records, err := reader.ReadAll()
	if err != nil {
		return nil, fmt.Errorf("failed to read package CSV file: %w", err)
	}

	// Skip header row
	if len(records) < 2 {
		return make(map[string]PackageCounts), nil
	}

	for i, record := range records[1:] { // Skip header
		if len(record) < 7 { // Minimum required fields for package data
			continue
		}

		// Parse the record into PackageData
		pkg, err := parsePackageCSVRecord(record)
		if err != nil {
			// Log error but continue processing other records
			fmt.Printf("Warning: skipping invalid package record at line %d: %v\n", i+2, err)
			continue
		}

		// Add to repository packages map
		if _, ok := repoPackages[pkg.Repo]; !ok {
			repoPackages[pkg.Repo] = make(map[string]PackageData)
		}
		repoPackages[pkg.Repo][pkg.PackageName] = pkg
	}

	// Convert to counts
	counts := make(map[string]PackageCounts)
	for repo, pkgs := range repoPackages {
		packageCount := len(pkgs)
		versionCount := 0

		// Sum up version counts for all packages in this repository
		for _, pkg := range pkgs {
			if pkg.VersionCount != nil {
				versionCount += *pkg.VersionCount
			}
		}

		counts[repo] = PackageCounts{
			PackageCount:    packageCount,
			PackageVersions: versionCount,
		}
	}

	return counts, nil
}

// GetPackageFilePath returns the file path for package data for a specific organization.
func GetPackageFilePath(org string) string {
	return fmt.Sprintf("%s-packages.csv", org)
}

// parsePackageCSVRecord parses a CSV record into a PackageData struct.
func parsePackageCSVRecord(record []string) (PackageData, error) {
	const minPackageFields = 7 // org, repo, packageName, packageType, visibility, createdAt, updatedAt
	if len(record) < minPackageFields {
		return PackageData{}, fmt.Errorf("insufficient fields in package record")
	}

	// Helper function to parse optional int
	parseOptionalInt := func(s string) *int {
		s = strings.TrimSpace(s)
		if s == "" {
			return nil
		}
		if i, err := strconv.Atoi(s); err == nil {
			return &i
		}
		return nil
	}

	pkg := PackageData{
		Org:         strings.TrimSpace(record[0]),
		Repo:        strings.TrimSpace(record[1]),
		PackageName: strings.TrimSpace(record[2]),
		PackageType: strings.TrimSpace(record[3]),
		Visibility:  strings.TrimSpace(record[4]),
		CreatedAt:   strings.TrimSpace(record[5]),
		UpdatedAt:   strings.TrimSpace(record[6]),
	}

	// Parse optional VersionCount if it exists
	if len(record) > 7 {
		pkg.VersionCount = parseOptionalInt(record[7])
	}

	return pkg, nil
}
