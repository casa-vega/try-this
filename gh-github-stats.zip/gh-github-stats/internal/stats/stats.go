// Package stats provides the core functionality for collecting GitHub repository statistics.
package stats

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/cvega/gh-github-stats/internal/ghapi"
	"github.com/cvega/gh-github-stats/internal/output"
	"github.com/cvega/gh-github-stats/internal/state"
	"github.com/pterm/pterm"
)

const (
	maxRetries     = 5
	initialBackoff = 1 * time.Second
)

// Config holds all configuration options for the stats collection.
// This struct is used to configure the behavior of the statistics collection process.
type Config struct {
	OrgName    string // Organization name to analyze (mutually exclusive with InputFile)
	InputFile  string // File with list of organizations to analyze (mutually exclusive with OrgName)
	OutputFile string // Output CSV file path for results
	MaxWorkers int    // Maximum number of concurrent API calls (default: 3)
	FailFast   bool   // Stop processing on first error
	Verbose    bool   // Enable verbose output and debug information
	Resume     bool   // Resume from existing output file, skipping already processed repositories
}

// RunWithContext orchestrates org/repo processing with context support for cancellation.
// Handles validation, error aggregation, and progress reporting for multiple orgs.
func RunWithContext(ctx context.Context, config Config) error {
	// Validate inputs
	if config.OrgName == "" && config.InputFile == "" {
		return fmt.Errorf("must specify either --org or --file")
	}

	if config.OrgName != "" {
		if err := validateOrgName(config.OrgName); err != nil {
			return fmt.Errorf("invalid organization name: %w", err)
		}
	}

	// Set default max workers if not specified
	if config.MaxWorkers <= 0 {
		config.MaxWorkers = 3
	}

	// Get initial rate limit info
	ghapi.UpdateRateLimitInfo()
	state.Get().PrintRateLimit()

	// Read existing CSV data to skip already processed repositories (only if resume is enabled)
	var existingStats map[string]output.RepoStats
	var err error
	if config.Resume {
		existingStats, err = output.ReadExistingCSV(config.OutputFile)
		if err != nil {
			return fmt.Errorf("reading existing CSV file: %w", err)
		}

		if len(existingStats) > 0 {
			pterm.Info.Printf("Found %d already processed repositories in %s\n", len(existingStats), config.OutputFile)
		}
	} else {
		existingStats = make(map[string]output.RepoStats)
	}

	orgs, err := loadOrgs(config.OrgName, config.InputFile)
	if err != nil {
		return err
	}

	var allStats []output.RepoStats
	var allErrors []error

	for _, org := range orgs {
		// Check for cancellation
		select {
		case <-ctx.Done():
			if errors.Is(ctx.Err(), context.Canceled) {
				return fmt.Errorf("operation cancelled by user: %w", ctx.Err())
			}
			return fmt.Errorf("operation cancelled: %w", ctx.Err())
		default:
		}

		// Print the organization being processed
		state.Get().PrintOrg(org)

		stats, errors, err := processOrg(ctx, org, config, existingStats)
		if err != nil {
			if config.FailFast {
				return fmt.Errorf("processing organization %s: %w", org, err)
			}
			allErrors = append(allErrors, fmt.Errorf("organization %s: %w", org, err))
			continue
		}
		allStats = append(allStats, stats...)
		allErrors = append(allErrors, errors...)
	}

	// Report any errors that occurred during processing
	if len(allErrors) > 0 {
		pterm.Warning.Printf("⚠ %d errors occurred during processing:\n", len(allErrors))
		for _, err := range allErrors {
			pterm.Warning.Printf("  - %s\n", err)
		}
	}

	// Write CSV output (append mode if resuming, overwrite if not)
	if config.Resume {
		if err := output.AppendToCSV(config.OutputFile, allStats); err != nil {
			return fmt.Errorf("writing CSV output: %w", err)
		}
	} else {
		if err := output.WriteCSV(config.OutputFile, allStats); err != nil {
			return fmt.Errorf("writing CSV output: %w", err)
		}
	}

	// Show final rate limit status
	ghapi.UpdateRateLimitInfo()
	state.Get().PrintRateLimit()

	state.Get().MarkDone()
	return nil
}

// validateOrgName checks if the organization name is valid according to GitHub's rules.
func validateOrgName(org string) error {
	if org == "" {
		return fmt.Errorf("organization name cannot be empty")
	}
	if strings.Contains(org, " ") {
		return fmt.Errorf("organization name cannot contain spaces")
	}
	if strings.Contains(org, "/") {
		return fmt.Errorf("organization name cannot contain forward slashes")
	}
	if strings.Contains(org, "\\") {
		return fmt.Errorf("organization name cannot contain backslashes")
	}
	if strings.Contains(org, "\n") || strings.Contains(org, "\r") {
		return fmt.Errorf("organization name cannot contain newlines")
	}
	if len(org) > 39 { // GitHub org name limit
		return fmt.Errorf("organization name too long (max 39 characters)")
	}
	return nil
}

// loadOrgs loads organization names from a file or single value, with validation and deduplication.
func loadOrgs(single string, file string) ([]string, error) {
	if single != "" {
		return []string{single}, nil
	}

	if file == "" {
		return nil, fmt.Errorf("must specify either --org or --file")
	}

	// Validate file path
	if strings.Contains(file, "..") {
		return nil, fmt.Errorf("invalid file path: %s", file)
	}

	content, err := os.ReadFile(file)
	if err != nil {
		return nil, fmt.Errorf("reading organization file %s: %w", file, err)
	}

	lines := splitLines(string(content))
	var orgs []string
	seen := make(map[string]bool)

	// Pre-allocate slice with reasonable capacity
	orgs = make([]string, 0, len(lines)/2) // Assume roughly half the lines are valid orgs

	for i, line := range lines {
		line = strings.TrimSpace(line)
		if line != "" && !strings.HasPrefix(line, "#") {
			if err := validateOrgName(line); err != nil {
				return nil, fmt.Errorf("invalid organization name at line %d: %q (%w)", i+1, line, err)
			}

			// Deduplicate orgs
			if !seen[line] {
				orgs = append(orgs, line)
				seen[line] = true
			}
		}
	}

	if len(orgs) == 0 {
		return nil, fmt.Errorf("no valid organizations found in file %s", file)
	}

	return orgs, nil
}

// fetchRepositoryNames fetches all repository names for an organization using GraphQL
func fetchRepositoryNames(org string) ([]string, error) {
	repoNamesQuery := `
	query($login: String!, $pageSize: Int!, $endCursor: String) {
		organization(login: $login) {
			repositories(first: $pageSize, after: $endCursor, orderBy: {field: NAME, direction: ASC}) {
				pageInfo {
					endCursor
					hasNextPage
				}
				nodes {
					name
				}
			}
		}
	}`

	vars := map[string]interface{}{
		"login":    org,
		"pageSize": 100, // Get more repos per page since we only need names
	}

	// Get all repository names
	pages, err := ghapi.RunGraphQLPaginated(repoNamesQuery, vars, func(data map[string]interface{}) (string, bool) {
		state.Get().IncrementAPICalls()
		return extractRepoPagination(data)
	})
	if err != nil {
		return nil, fmt.Errorf("fetching repository names: %w", err)
	}

	// Pre-allocate slice with reasonable capacity (100 repos per page)
	allRepoNames := make([]string, 0, len(pages)*100)

	// Extract repository names
	for _, page := range pages {
		repos := extractRepoNodes(page)
		for _, r := range repos {
			allRepoNames = append(allRepoNames, r["name"].(string))
		}
	}

	return allRepoNames, nil
}

// filterProcessedRepos filters out already processed repositories and returns unprocessed ones
func filterProcessedRepos(allRepoNames []string, org string, existingStats map[string]output.RepoStats, config Config) ([]string, int) {
	unprocessedRepoNames := make([]string, 0, len(allRepoNames))
	skippedCount := 0

	for _, repoName := range allRepoNames {
		key := fmt.Sprintf("%s/%s", org, repoName)
		if _, exists := existingStats[key]; exists {
			skippedCount++
			if config.Verbose {
				pterm.Debug.Printf("Skipping already processed repository: %s/%s\n", org, repoName)
			}
		} else {
			unprocessedRepoNames = append(unprocessedRepoNames, repoName)
		}
	}

	if skippedCount > 0 {
		pterm.Info.Printf("Skipping %d already processed repositories in %s\n", skippedCount, org)
	}

	// Update total repos (only count unprocessed ones)
	state.Get().AddRepos(len(unprocessedRepoNames))

	if config.Verbose {
		pterm.Info.Printf("Found %d repositories in %s (%d new, %d already processed)\n",
			len(allRepoNames), org, len(unprocessedRepoNames), skippedCount)
	}

	return unprocessedRepoNames, skippedCount
}

// loadExistingPackageData loads existing package data if resume is enabled
func loadExistingPackageData(org string, config Config) map[string]output.PackageCounts {
	if !config.Resume {
		return nil
	}

	packageFilePath := output.GetPackageFilePath(org)
	existingPackageCounts, err := output.ReadPackageDataWithVersions(packageFilePath)
	if err != nil {
		pterm.Warning.Printf("Failed to read existing package data for %s: %v\n", org, err)
		return nil
	}

	if len(existingPackageCounts) > 0 {
		pterm.Info.Printf("Found existing package data for %s (%d repositories)\n", org, len(existingPackageCounts))
	}

	return existingPackageCounts
}

// fetchPackageData fetches package data for the organization
func fetchPackageData(org string, existingPackageCounts map[string]output.PackageCounts, config Config) map[string]output.PackageCounts {
	packageFilePath := output.GetPackageFilePath(org)

	// Always fetch package data (with resume support if enabled)
	packageProgress, _ := pterm.DefaultProgressbar.WithTotal(6).WithTitle("Fetching packages...").Start()

	packageStart := time.Now()
	packageData, err := ghapi.GetOrgPackageDataWithResume(org, packageProgress, existingPackageCounts, packageFilePath, config.Verbose)
	if err != nil {
		pterm.Warning.Printf("Failed to fetch package data for %s: %v\n", org, err)
		// Continue with empty package data rather than failing completely
		packageData = make(map[string]output.PackageCounts)
	}
	if config.Verbose {
		pterm.Debug.Printf("Package data fetched in %v\n", time.Since(packageStart))
	}

	return packageData
}

// processRepositories processes the repositories and returns statistics and errors
func processRepositories(ctx context.Context, org string, repoNames []string, packageData map[string]output.PackageCounts, config Config) ([]output.RepoStats, []error) {
	if len(repoNames) == 0 {
		pterm.Info.Printf("All repositories in %s have already been processed\n", org)
		return []output.RepoStats{}, []error{}
	}

	// Process each repository individually with a progress bar
	repoProgress, _ := pterm.DefaultProgressbar.WithTotal(len(repoNames)).WithTitle(fmt.Sprintf("Processing %d repositories...", len(repoNames))).Start()
	defer repoProgress.Stop()

	repoStart := time.Now()
	stats, errors := processReposParallel(ctx, org, repoNames, packageData, repoProgress, config)
	if config.Verbose {
		pterm.Debug.Printf("Repository processing completed in %v\n", time.Since(repoStart))
	}

	return stats, errors
}

// processOrg fetches all repositories for an org, collects their statistics, and returns the results.
// Handles progress reporting, error aggregation, and cancellation via context.
func processOrg(ctx context.Context, org string, config Config, existingStats map[string]output.RepoStats) ([]output.RepoStats, []error, error) {
	startTime := time.Now()

	// Step 1: Fetch all repository names
	allRepoNames, err := fetchRepositoryNames(org)
	if err != nil {
		return nil, nil, err
	}

	// Step 2: Filter out already processed repositories
	unprocessedRepoNames, _ := filterProcessedRepos(allRepoNames, org, existingStats, config)

	// Step 3: Load existing package data if resuming
	existingPackageCounts := loadExistingPackageData(org, config)

	// Step 4: Fetch package data
	packageData := fetchPackageData(org, existingPackageCounts, config)

	// Step 5: Process repositories
	stats, errors := processRepositories(ctx, org, unprocessedRepoNames, packageData, config)

	// Step 6: Log completion summary
	if config.Verbose {
		totalTime := time.Since(startTime)
		pterm.Info.Printf("Organization %s completed in %v (%d repos, %d errors)\n",
			org, totalTime, len(stats), len(errors))
	}

	return stats, errors, nil
}

// processReposParallel processes repositories concurrently, collecting statistics for each.
// Respects context cancellation and limits concurrency via a semaphore.
func processReposParallel(ctx context.Context, org string, repoNames []string, packageData map[string]output.PackageCounts, progress *pterm.ProgressbarPrinter, config Config) ([]output.RepoStats, []error) {
	semaphore := make(chan struct{}, config.MaxWorkers)

	var (
		statsMu sync.Mutex
		stats   []output.RepoStats
		errors  []error
	)

	var wg sync.WaitGroup

	// Start workers
	for _, repoName := range repoNames {
		wg.Add(1)
		go func(name string) {
			defer wg.Done()

			// Try to acquire semaphore with context cancellation
			select {
			case semaphore <- struct{}{}:
				defer func() { <-semaphore }() // Release semaphore
			case <-ctx.Done():
				return // Context cancelled, exit early
			}

			if config.Verbose {
				pterm.Debug.Printf("Processing repository: %s\n", name)
			}

			// Check for cancellation before processing
			select {
			case <-ctx.Done():
				return
			default:
			}

			repoData, err := getRepoDetails(org, name, packageData)

			statsMu.Lock()
			defer statsMu.Unlock()

			if err != nil {
				state.Get().PrintRepo(name, false)
				errors = append(errors, fmt.Errorf("%s: %w", name, err))
			} else {
				state.Get().PrintRepo(name, true)
				stats = append(stats, repoData)
			}

			if progress != nil {
				progress.Increment()
			}
		}(repoName)
	}

	// Wait for all workers with context cancellation
	done := make(chan struct{})
	go func() {
		wg.Wait()
		close(done)
	}()

	select {
	case <-done:
		// All workers completed normally
	case <-ctx.Done():
		// Context cancelled, wait for workers to finish but don't block indefinitely
		pterm.Warning.Println("Cancellation requested, waiting for workers to finish...")
		select {
		case <-done:
			pterm.Info.Println("All workers finished gracefully")
		case <-time.After(5 * time.Second):
			pterm.Warning.Println("Some workers may not have finished")
		}
	}

	return stats, errors
}

// getRepoDetails fetches all statistics for a single repository, including basic and detailed stats.
func getRepoDetails(org, repoName string, packageData map[string]output.PackageCounts) (output.RepoStats, error) {
	// Query for a single repository with all its details, including latest release
	query := `
	query($login: String!, $repoName: String!) {
		organization(login: $login) {
			repository(name: $repoName) {
				name
				url
				isFork
				isArchived
				diskUsage
				hasWikiEnabled
				createdAt
				updatedAt
				pushedAt
				collaborators { totalCount }
				refs(refPrefix: "refs/heads/") { totalCount }
				tags: refs(refPrefix: "refs/tags/") { totalCount }
				branchProtectionRules { totalCount }
				issues { totalCount }
				pullRequests { totalCount }
				milestones { totalCount }
				releases { totalCount }
				projects { totalCount }
				discussions { totalCount }
				commitComments { totalCount }
			}
		}
	}`

	vars := map[string]interface{}{
		"login":    org,
		"repoName": repoName,
	}

	result, err := ghapi.RunGraphQLPaginated(query, vars, func(data map[string]interface{}) (string, bool) {
		return "", false // No pagination needed for single repo
	})
	if err != nil {
		return output.RepoStats{}, fmt.Errorf("fetching repository data: %w", err)
	}

	// Extract the repository data
	repoData := result[0]["data"].(map[string]interface{})["organization"].(map[string]interface{})["repository"].(map[string]interface{})
	r := repoData

	// Get issue events count using REST API
	issueEventsCount, err := getIssueEventsCount(org, repoName)
	if err != nil {
		// Log error but don't fail the entire operation
		pterm.Warning.Printf("Failed to get issue events count for %s/%s: %v\n", org, repoName, err)
		issueEventsCount = 0
	}

	// Build basic repo stats
	stats := buildBasicRepoStats(org, r, packageData, issueEventsCount)

	return stats, nil
}

// parseLinkHeader extracts total count from Link header
func parseLinkHeader(lines []string) (int, bool) {
	for _, line := range lines {
		if strings.HasPrefix(line, "Link:") && strings.Contains(line, "rel=\"last\"") {
			lastMatch := strings.Split(line, "page=")
			if len(lastMatch) > 1 {
				pagePart := strings.Split(lastMatch[len(lastMatch)-1], ">")[0]
				if pageNum, err := strconv.Atoi(pagePart); err == nil {
					return pageNum, true
				}
			}
		}
	}
	return 0, false
}

// parseResponseBody extracts and counts events from response body
func parseResponseBody(lines []string) (int, error) {
	bodyStart := false
	var bodyLines []string
	for _, line := range lines {
		if bodyStart {
			bodyLines = append(bodyLines, line)
		}
		if strings.TrimSpace(line) == "" {
			bodyStart = true
		}
	}
	body := strings.Join(bodyLines, "\n")
	var events []map[string]interface{}
	if err := json.Unmarshal([]byte(body), &events); err == nil {
		return len(events), nil
	}
	return 0, fmt.Errorf("failed to parse response body")
}

// getIssueEventsCount gets the total count of issue events for a repository using the REST API
func getIssueEventsCount(org, repoName string) (int, error) {
	endpoint := fmt.Sprintf("/repos/%s/%s/issues/events?per_page=1", org, repoName)

	var lastErr error
	for attempt := 0; attempt < maxRetries; attempt++ {
		cmd := exec.Command("gh", "api", "--include", endpoint)
		cmd.Env = os.Environ()
		var stdout, stderr bytes.Buffer
		cmd.Stdout = &stdout
		cmd.Stderr = &stderr

		if err := cmd.Run(); err == nil {
			state.Get().IncrementAPICalls()

			response := stdout.String()
			lines := strings.Split(response, "\n")

			// Try to get count from Link header first
			if count, found := parseLinkHeader(lines); found {
				return count, nil
			}

			// Fallback to parsing response body
			if count, err := parseResponseBody(lines); err == nil {
				return count, nil
			}

			return 0, nil
		} else {
			lastErr = fmt.Errorf("failed to get issue events: %w, stderr: %s", err, stderr.String())
			// Retry on server errors
			if strings.Contains(stderr.String(), "Server Error") || strings.Contains(stderr.String(), "502") {
				backoff := time.Duration(math.Pow(2, float64(attempt))) * initialBackoff
				time.Sleep(backoff)
				continue
			} else {
				return 0, lastErr
			}
		}
	}
	return 0, fmt.Errorf("all retries failed: %w", lastErr)
}

// buildBasicRepoStats constructs the basic statistics for a repository from the GraphQL response.
func buildBasicRepoStats(org string, r map[string]interface{}, packageData map[string]output.PackageCounts, issueEventsCount int) output.RepoStats {
	repoName := r["name"].(string)
	packageCount := 0
	packageVersions := 0

	// Get package data for this repository
	if pkgData, exists := packageData[repoName]; exists {
		packageCount = pkgData.PackageCount
		packageVersions = pkgData.PackageVersions
	}

	return output.RepoStats{
		Org:        org,
		Name:       repoName,
		URL:        r["url"].(string),
		IsFork:     r["isFork"].(bool),
		IsArchived: r["isArchived"].(bool),
		SizeMB:     int(r["diskUsage"].(float64)) / 1024,
		HasWiki:    r["hasWikiEnabled"].(bool),
		CreatedAt:  r["createdAt"].(string),
		UpdatedAt:  r["updatedAt"].(string),
		PushedAt:   r["pushedAt"].(string),

		Collaborators:     int(r["collaborators"].(map[string]interface{})["totalCount"].(float64)),
		Branches:          int(r["refs"].(map[string]interface{})["totalCount"].(float64)),
		Tags:              int(r["tags"].(map[string]interface{})["totalCount"].(float64)),
		ProtectedBranches: int(r["branchProtectionRules"].(map[string]interface{})["totalCount"].(float64)),
		Issues:            int(r["issues"].(map[string]interface{})["totalCount"].(float64)),
		PRs:               int(r["pullRequests"].(map[string]interface{})["totalCount"].(float64)),
		Milestones:        int(r["milestones"].(map[string]interface{})["totalCount"].(float64)),
		Releases:          int(r["releases"].(map[string]interface{})["totalCount"].(float64)),
		Discussions:       int(r["discussions"].(map[string]interface{})["totalCount"].(float64)),
		CommitComments:    int(r["commitComments"].(map[string]interface{})["totalCount"].(float64)),
		IssueEvents:       issueEventsCount, // Use the count from REST API
		Projects:          int(r["projects"].(map[string]interface{})["totalCount"].(float64)),

		Packages:        packageCount,
		PackageVersions: packageVersions,
	}
}

// extractRepoPagination extracts the endCursor and hasNextPage from a GraphQL response page.
func extractRepoPagination(data map[string]interface{}) (string, bool) {
	orgData := data["data"].(map[string]interface{})["organization"].(map[string]interface{})
	pageInfo := orgData["repositories"].(map[string]interface{})["pageInfo"].(map[string]interface{})
	endCursor := pageInfo["endCursor"].(string)
	hasNextPage := pageInfo["hasNextPage"].(bool)
	return endCursor, hasNextPage
}

// extractRepoNodes extracts the repository nodes from a GraphQL response page.
func extractRepoNodes(data map[string]interface{}) []map[string]interface{} {
	org := data["data"].(map[string]interface{})["organization"].(map[string]interface{})
	nodes := org["repositories"].(map[string]interface{})["nodes"].([]interface{})
	result := make([]map[string]interface{}, len(nodes))
	for i, node := range nodes {
		result[i] = node.(map[string]interface{})
	}
	return result
}

// splitLines splits a string into lines, handling both \n and \r.
// Pre-allocates the result slice for better performance.
func splitLines(input string) []string {
	// Pre-allocate with reasonable capacity (roughly 1 line per 50 characters)
	lines := make([]string, 0, len(input)/50+1)
	var builder strings.Builder
	builder.Grow(len(input)) // Pre-allocate builder capacity

	for _, r := range input {
		if r == '\n' || r == '\r' {
			if builder.Len() > 0 {
				lines = append(lines, builder.String())
				builder.Reset()
			}
		} else {
			builder.WriteRune(r)
		}
	}
	if builder.Len() > 0 {
		lines = append(lines, builder.String())
	}
	return lines
}
