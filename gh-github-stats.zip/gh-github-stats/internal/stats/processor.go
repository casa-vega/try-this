package stats

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/cvega/gh-github-stats/internal/ghapi"
	"github.com/cvega/gh-github-stats/internal/output"
	"github.com/cvega/gh-github-stats/internal/state"
	"github.com/pterm/pterm"
)

const (
	maxRetries     = 5
	initialBackoff = 1 * time.Second
)

// Config holds all configuration options for the stats collection.
// This struct is used to configure the behavior of the statistics collection process.
type Config struct {
	OrgName    string // Organization name to analyze (mutually exclusive with InputFile)
	InputFile  string // File with list of organizations to analyze (mutually exclusive with OrgName)
	OutputFile string // Output CSV file path for results
	MaxWorkers int    // Maximum number of concurrent API calls (default: 3)
	FailFast   bool   // Stop processing on first error
	Verbose    bool   // Enable verbose output and debug information
	Resume     bool   // Resume from existing output file, skipping already processed repositories
}

// RunWithContext orchestrates org/repo processing with context support for cancellation.
// Handles validation, error aggregation, and progress reporting for multiple orgs.
func RunWithContext(ctx context.Context, config Config) error {
	// Validate inputs
	if config.OrgName == "" && config.InputFile == "" {
		return fmt.Errorf("must specify either --org or --file")
	}

	if config.OrgName != "" {
		if err := validateOrgName(config.OrgName); err != nil {
			return fmt.Errorf("invalid organization name: %w", err)
		}
	}

	// Set default max workers if not specified
	if config.MaxWorkers <= 0 {
		config.MaxWorkers = 3
	}

	// Get initial rate limit info
	ghapi.UpdateRateLimitInfo()
	state.Get().PrintRateLimit()

	// Read existing CSV data to skip already processed repositories (only if resume is enabled)
	var existingStats map[string]output.RepoStats
	var err error
	if config.Resume {
		existingStats, err = output.ReadExistingCSV(config.OutputFile)
		if err != nil {
			return fmt.Errorf("reading existing CSV file: %w", err)
		}

		if len(existingStats) > 0 {
			pterm.Info.Printf("Found %d already processed repositories in %s\n", len(existingStats), config.OutputFile)
		}
	} else {
		existingStats = make(map[string]output.RepoStats)
	}

	orgs, err := loadOrgs(config.OrgName, config.InputFile)
	if err != nil {
		return err
	}

	var allStats []output.RepoStats
	var allErrors []error

	for _, org := range orgs {
		// Check for cancellation
		select {
		case <-ctx.Done():
			if errors.Is(ctx.Err(), context.Canceled) {
				return fmt.Errorf("operation cancelled by user: %w", ctx.Err())
			}
			return fmt.Errorf("operation cancelled: %w", ctx.Err())
		default:
		}

		// Print the organization being processed
		state.Get().PrintOrg(org)

		stats, errors, err := processOrg(ctx, org, config, existingStats)
		if err != nil {
			if config.FailFast {
				return fmt.Errorf("processing organization %s: %w", org, err)
			}
			allErrors = append(allErrors, fmt.Errorf("organization %s: %w", org, err))
			continue
		}
		allStats = append(allStats, stats...)
		allErrors = append(allErrors, errors...)
	}

	// Report any errors that occurred during processing
	if len(allErrors) > 0 {
		pterm.Warning.Printf("⚠ %d errors occurred during processing:\n", len(allErrors))
		for _, err := range allErrors {
			pterm.Warning.Printf("  - %s\n", err)
		}
	}

	// Write CSV output (append mode if resuming, overwrite if not)
	if config.Resume {
		if err := output.AppendToCSV(config.OutputFile, allStats); err != nil {
			return fmt.Errorf("writing CSV output: %w", err)
		}
	} else {
		if err := output.WriteCSV(config.OutputFile, allStats); err != nil {
			return fmt.Errorf("writing CSV output: %w", err)
		}
	}

	// Show final rate limit status
	ghapi.UpdateRateLimitInfo()
	state.Get().PrintRateLimit()

	state.Get().MarkDone()
	return nil
}

// filterProcessedRepos filters out already processed repositories and returns unprocessed ones
func filterProcessedRepos(allRepoNames []string, org string, existingStats map[string]output.RepoStats, config Config) ([]string, int) {
	unprocessedRepoNames := make([]string, 0, len(allRepoNames))
	skippedCount := 0

	for _, repoName := range allRepoNames {
		key := fmt.Sprintf("%s/%s", org, repoName)
		if _, exists := existingStats[key]; exists {
			skippedCount++
			if config.Verbose {
				pterm.Debug.Printf("Skipping already processed repository: %s/%s\n", org, repoName)
			}
		} else {
			unprocessedRepoNames = append(unprocessedRepoNames, repoName)
		}
	}

	if skippedCount > 0 {
		pterm.Info.Printf("Skipping %d already processed repositories in %s\n", skippedCount, org)
	}

	// Update total repos (only count unprocessed ones)
	state.Get().AddRepos(len(unprocessedRepoNames))

	if config.Verbose {
		pterm.Info.Printf("Found %d repositories in %s (%d new, %d already processed)\n",
			len(allRepoNames), org, len(unprocessedRepoNames), skippedCount)
	}

	return unprocessedRepoNames, skippedCount
}

// loadExistingPackageData loads existing package data if resume is enabled
func loadExistingPackageData(org string, config Config) map[string]output.PackageCounts {
	if !config.Resume {
		return nil
	}

	packageFilePath := output.GetPackageFilePath(org)
	existingPackageCounts, err := output.ReadPackageDataWithVersions(packageFilePath)
	if err != nil {
		pterm.Warning.Printf("Failed to read existing package data for %s: %v\n", org, err)
		return nil
	}

	if len(existingPackageCounts) > 0 {
		pterm.Info.Printf("Found existing package data for %s (%d repositories)\n", org, len(existingPackageCounts))
	}

	return existingPackageCounts
}

// fetchPackageData fetches package data for the organization
func fetchPackageData(org string, existingPackageCounts map[string]output.PackageCounts, config Config) map[string]output.PackageCounts {
	packageFilePath := output.GetPackageFilePath(org)

	// Always fetch package data (with resume support if enabled)
	packageProgress, _ := pterm.DefaultProgressbar.WithTotal(6).WithTitle("Fetching packages...").Start()

	packageStart := time.Now()
	packageData, err := ghapi.GetOrgPackageDataWithResume(org, packageProgress, existingPackageCounts, packageFilePath, config.Verbose)
	if err != nil {
		pterm.Warning.Printf("Failed to fetch package data for %s: %v\n", org, err)
		// Continue with empty package data rather than failing completely
		packageData = make(map[string]output.PackageCounts)
	}
	if config.Verbose {
		pterm.Debug.Printf("Package data fetched in %v\n", time.Since(packageStart))
	}

	return packageData
}

// processRepositories processes the repositories and returns statistics and errors
func processRepositories(ctx context.Context, org string, repoNames []string, packageData map[string]output.PackageCounts, config Config) ([]output.RepoStats, []error) {
	if len(repoNames) == 0 {
		pterm.Info.Printf("All repositories in %s have already been processed\n", org)
		return []output.RepoStats{}, []error{}
	}

	// Process each repository individually with a progress bar
	repoProgress, _ := pterm.DefaultProgressbar.WithTotal(len(repoNames)).WithTitle(fmt.Sprintf("Processing %d repositories...", len(repoNames))).Start()

	return processReposParallel(ctx, org, repoNames, packageData, repoProgress, config)
}

// processOrg processes a single organization and returns statistics and errors
func processOrg(ctx context.Context, org string, config Config, existingStats map[string]output.RepoStats) ([]output.RepoStats, []error, error) {
	// Fetch all repository names for this organization
	allRepoNames, err := fetchRepositoryNames(org)
	if err != nil {
		return nil, nil, fmt.Errorf("fetching repository names: %w", err)
	}

	// Filter out already processed repositories
	repoNames, _ := filterProcessedRepos(allRepoNames, org, existingStats, config)

	// Load existing package data if resume is enabled
	existingPackageCounts := loadExistingPackageData(org, config)

	// Fetch package data for the organization
	packageData := fetchPackageData(org, existingPackageCounts, config)

	// Process repositories
	stats, errors := processRepositories(ctx, org, repoNames, packageData, config)

	return stats, errors, nil
}
