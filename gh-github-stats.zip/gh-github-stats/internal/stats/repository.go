package stats

import (
	"fmt"

	"github.com/cvega/gh-github-stats/internal/ghapi"
	"github.com/cvega/gh-github-stats/internal/output"
	"github.com/cvega/gh-github-stats/internal/state"
)

// fetchRepositoryNames fetches all repository names for an organization using GraphQL
func fetchRepositoryNames(org string) ([]string, error) {
	repoNamesQuery := `
	query($login: String!, $pageSize: Int!, $endCursor: String) {
		organization(login: $login) {
			repositories(first: $pageSize, after: $endCursor, orderBy: {field: NAME, direction: ASC}) {
				pageInfo {
					endCursor
					hasNextPage
				}
				nodes {
					name
				}
			}
		}
	}`

	vars := map[string]interface{}{
		"login":    org,
		"pageSize": 100, // Get more repos per page since we only need names
	}

	// Get all repository names
	pages, err := ghapi.RunGraphQLPaginated(repoNamesQuery, vars, func(data map[string]interface{}) (string, bool) {
		state.Get().IncrementAPICalls()
		return extractRepoPagination(data)
	})
	if err != nil {
		return nil, fmt.Errorf("fetching repository names: %w", err)
	}

	// Pre-allocate slice with reasonable capacity (100 repos per page)
	allRepoNames := make([]string, 0, len(pages)*100)

	// Extract repository names
	for _, page := range pages {
		repos := extractRepoNodes(page)
		for _, r := range repos {
			allRepoNames = append(allRepoNames, r["name"].(string))
		}
	}

	return allRepoNames, nil
}

// getRepoDetails fetches all statistics for a single repository, including basic and detailed stats.
func getRepoDetails(org, repoName string, packageData map[string]output.PackageCounts) (output.RepoStats, error) {
	// Query for a single repository with all its details, including latest release
	query := `
	query($login: String!, $repoName: String!) {
		organization(login: $login) {
			repository(name: $repoName) {
				name
				url
				isFork
				isArchived
				diskUsage
				hasWikiEnabled
				createdAt
				updatedAt
				pushedAt
				collaborators {
					totalCount
				}
				branches: refs(refPrefix: "refs/heads/") {
					totalCount
				}
				tags: refs(refPrefix: "refs/tags/") {
					totalCount
				}
				defaultBranchRef {
					branchProtectionRules {
						totalCount
					}
				}
				issues {
					totalCount
				}
				pullRequests {
					totalCount
				}
				milestones {
					totalCount
				}
				releases {
					totalCount
				}
				projectsV2 {
					totalCount
				}
				discussions {
					totalCount
				}
				commitComments {
					totalCount
				}
			}
		}
	}`

	vars := map[string]interface{}{
		"login":    org,
		"repoName": repoName,
	}

	// Execute the GraphQL query
	result, err := ghapi.RunGraphQLPaginated(query, vars, func(data map[string]interface{}) (string, bool) {
		state.Get().IncrementAPICalls()
		return "", false // Single page query
	})
	if err != nil {
		return output.RepoStats{}, fmt.Errorf("GraphQL query failed: %w", err)
	}

	// Get issue events count using REST API
	issueEventsCount, err := getIssueEventsCount(org, repoName)
	if err != nil {
		// Log error but continue with 0 count
		// Note: This will be handled by the calling function
		issueEventsCount = 0
	}

	// Extract repository data from the first (and only) page
	if len(result) == 0 {
		return output.RepoStats{}, fmt.Errorf("no data returned for repository %s", repoName)
	}

	repoData := result[0]
	orgData, ok := repoData["organization"].(map[string]interface{})
	if !ok {
		return output.RepoStats{}, fmt.Errorf("invalid organization data structure")
	}

	repo, ok := orgData["repository"].(map[string]interface{})
	if !ok {
		return output.RepoStats{}, fmt.Errorf("repository %s not found", repoName)
	}

	// Build the repository statistics
	return buildBasicRepoStats(org, repo, packageData, issueEventsCount), nil
}

// buildBasicRepoStats builds the RepoStats struct from the repository data and package counts.
func buildBasicRepoStats(org string, r map[string]interface{}, packageData map[string]output.PackageCounts, issueEventsCount int) output.RepoStats {
	getString := func(key string) string {
		if val, ok := r[key].(string); ok {
			return val
		}
		return ""
	}
	getBool := func(key string) bool {
		if val, ok := r[key].(bool); ok {
			return val
		}
		return false
	}
	getInt := func(key string) int {
		if val, ok := r[key].(float64); ok {
			return int(val)
		}
		return 0
	}
	getTotalCount := func(key string) int {
		if m, ok := r[key].(map[string]interface{}); ok {
			if val, ok := m["totalCount"].(float64); ok {
				return int(val)
			}
		}
		return 0
	}

	protectedBranches := 0
	if defBranch, ok := r["defaultBranchRef"].(map[string]interface{}); ok {
		if bpr, ok := defBranch["branchProtectionRules"].(map[string]interface{}); ok {
			if val, ok := bpr["totalCount"].(float64); ok {
				protectedBranches = int(val)
			}
		}
	}

	repoName := getString("name")
	repoKey := fmt.Sprintf("%s/%s", org, repoName)
	packageCounts := packageData[repoKey]

	return output.RepoStats{
		Org:               org,
		Name:              repoName,
		URL:               getString("url"),
		IsFork:            getBool("isFork"),
		IsArchived:        getBool("isArchived"),
		SizeMB:            getInt("diskUsage"),
		HasWiki:           getBool("hasWikiEnabled"),
		CreatedAt:         getString("createdAt"),
		UpdatedAt:         getString("updatedAt"),
		PushedAt:          getString("pushedAt"),
		Collaborators:     getTotalCount("collaborators"),
		Branches:          getTotalCount("branches"),
		Tags:              getTotalCount("tags"),
		ProtectedBranches: protectedBranches,
		Issues:            getTotalCount("issues"),
		PRs:               getTotalCount("pullRequests"),
		Milestones:        getTotalCount("milestones"),
		Releases:          getTotalCount("releases"),
		Projects:          getTotalCount("projectsV2"),
		Discussions:       getTotalCount("discussions"),
		CommitComments:    getTotalCount("commitComments"),
		IssueEvents:       issueEventsCount,
		Packages:          packageCounts.PackageCount,
		PackageVersions:   packageCounts.PackageVersions,
	}
}

// extractRepoPagination extracts the endCursor and hasNextPage from the GraphQL response.
func extractRepoPagination(data map[string]interface{}) (string, bool) {
	org, ok := data["organization"].(map[string]interface{})
	if !ok {
		return "", false
	}
	repos, ok := org["repositories"].(map[string]interface{})
	if !ok {
		return "", false
	}
	pageInfo, ok := repos["pageInfo"].(map[string]interface{})
	if !ok {
		return "", false
	}
	endCursor, _ := pageInfo["endCursor"].(string)
	hasNextPage, _ := pageInfo["hasNextPage"].(bool)
	return endCursor, hasNextPage
}

// extractRepoNodes extracts the repository nodes from the GraphQL response.
func extractRepoNodes(data map[string]interface{}) []map[string]interface{} {
	org, ok := data["organization"].(map[string]interface{})
	if !ok {
		return nil
	}
	repos, ok := org["repositories"].(map[string]interface{})
	if !ok {
		return nil
	}
	nodes, ok := repos["nodes"].([]interface{})
	if !ok {
		return nil
	}
	result := make([]map[string]interface{}, 0, len(nodes))
	for _, n := range nodes {
		if m, ok := n.(map[string]interface{}); ok {
			result = append(result, m)
		}
	}
	return result
}
