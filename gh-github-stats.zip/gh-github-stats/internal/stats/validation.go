package stats

import (
	"fmt"
	"os"
	"strings"
)

// validateOrgName checks if the organization name is valid according to GitHub's rules.
func validateOrgName(org string) error {
	if org == "" {
		return fmt.Errorf("organization name cannot be empty")
	}
	if strings.Contains(org, " ") {
		return fmt.Errorf("organization name cannot contain spaces")
	}
	if strings.Contains(org, "/") {
		return fmt.Errorf("organization name cannot contain forward slashes")
	}
	if strings.Contains(org, "\\") {
		return fmt.Errorf("organization name cannot contain backslashes")
	}
	if strings.Contains(org, "\n") || strings.Contains(org, "\r") {
		return fmt.Errorf("organization name cannot contain newlines")
	}
	if len(org) > 39 { // GitHub org name limit
		return fmt.Errorf("organization name too long (max 39 characters)")
	}
	return nil
}

// loadOrgs loads organization names from a file or single value, with validation and deduplication.
func loadOrgs(single string, file string) ([]string, error) {
	if single != "" {
		return []string{single}, nil
	}

	if file == "" {
		return nil, fmt.Errorf("must specify either --org or --file")
	}

	// Validate file path
	if strings.Contains(file, "..") {
		return nil, fmt.Errorf("invalid file path: %s", file)
	}

	content, err := os.ReadFile(file)
	if err != nil {
		return nil, fmt.Errorf("reading organization file %s: %w", file, err)
	}

	lines := splitLines(string(content))
	var orgs []string
	seen := make(map[string]bool)

	// Pre-allocate slice with reasonable capacity
	orgs = make([]string, 0, len(lines)/2) // Assume roughly half the lines are valid orgs

	for i, line := range lines {
		line = strings.TrimSpace(line)
		if line != "" && !strings.HasPrefix(line, "#") {
			if err := validateOrgName(line); err != nil {
				return nil, fmt.Errorf("invalid organization name at line %d: %q (%w)", i+1, line, err)
			}

			// Deduplicate orgs
			if !seen[line] {
				orgs = append(orgs, line)
				seen[line] = true
			}
		}
	}

	if len(orgs) == 0 {
		return nil, fmt.Errorf("no valid organizations found in file %s", file)
	}

	return orgs, nil
}

// splitLines splits input into lines, handling both Unix and Windows line endings.
// Returns a slice of non-empty lines with whitespace trimmed.
func splitLines(input string) []string {
	// Normalize line endings and split
	lines := strings.Split(strings.ReplaceAll(input, "\r\n", "\n"), "\n")

	var result []string
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line != "" {
			result = append(result, line)
		}
	}

	return result
}
