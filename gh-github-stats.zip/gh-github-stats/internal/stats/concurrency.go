package stats

import (
	"context"
	"fmt"
	"sync"

	"github.com/cvega/gh-github-stats/internal/output"
	"github.com/cvega/gh-github-stats/internal/state"
	"github.com/pterm/pterm"
)

// processReposParallel processes repositories in parallel with a semaphore for concurrency control
func processReposParallel(
	ctx context.Context,
	org string,
	repoNames []string,
	packageData map[string]output.PackageCounts,
	progress *pterm.ProgressbarPrinter,
	config Config,
) ([]output.RepoStats, []error) {
	var stats []output.RepoStats
	var errors []error
	var mu sync.Mutex

	// Create a semaphore to limit concurrent API calls
	sem := make(chan struct{}, config.MaxWorkers)

	// Create a WaitGroup to wait for all goroutines to complete
	var wg sync.WaitGroup

	// Process repositories in parallel
	for _, repoName := range repoNames {
		wg.Add(1)
		go func(name string) {
			defer wg.Done()

			// Acquire semaphore
			sem <- struct{}{}
			defer func() { <-sem }()

			// Check for cancellation
			select {
			case <-ctx.Done():
				return
			default:
			}

			// Process the repository
			repoStats, err := getRepoDetails(org, name, packageData)

			// Update progress bar
			progress.Increment()

			// Thread-safe updates
			mu.Lock()
			if err != nil {
				errors = append(errors, fmt.Errorf("%s/%s: %w", org, name, err))
				state.Get().PrintRepo(name, false)
			} else {
				stats = append(stats, repoStats)
				state.Get().PrintRepo(name, true)
			}
			mu.Unlock()
		}(repoName)
	}

	// Wait for all goroutines to complete
	wg.Wait()

	return stats, errors
}
