package stats

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"time"

	"github.com/cvega/gh-github-stats/internal/state"
)

// getIssueEventsCount gets the total count of issue events for a repository using the REST API
// Includes retry logic with exponential backoff for server errors
func getIssueEventsCount(org, repoName string) (int, error) {
	endpoint := fmt.Sprintf("/repos/%s/%s/issues/events?per_page=1", org, repoName)

	var lastErr error
	for attempt := 0; attempt < maxRetries; attempt++ {
		cmd := exec.Command("gh", "api", "--include", endpoint)
		cmd.Env = os.Environ()
		var stdout, stderr bytes.Buffer
		cmd.Stdout = &stdout
		cmd.Stderr = &stderr

		runErr := cmd.Run()
		if runErr == nil {
			state.Get().IncrementAPICalls() // Count this API call

			// Parse Link header for last page
			headersAndBody := stdout.String()
			headerEnd := strings.Index(headersAndBody, "\r\n\r\n")
			if headerEnd == -1 {
				headerEnd = strings.Index(headersAndBody, "\n\n")
			}
			headers := headersAndBody[:headerEnd]
			linkHeader := ""
			for _, line := range strings.Split(headers, "\n") {
				if strings.HasPrefix(strings.ToLower(line), "link:") {
					linkHeader = line
					break
				}
			}
			if linkHeader == "" {
				// Only one page, so count is either 0 or 1
				body := headersAndBody[headerEnd+2:]
				var events []interface{}
				if jsonErr := json.Unmarshal([]byte(body), &events); jsonErr == nil {
					return len(events), nil
				}
				return 0, nil
			}
			// Extract last page number from Link header
			lastPage := 1
			links := strings.Split(linkHeader, ",")
			for _, link := range links {
				if strings.Contains(link, `rel="last"`) {
					parts := strings.Split(link, ";")
					if len(parts) > 0 {
						urlPart := parts[0]
						pageIdx := strings.Index(urlPart, "page=")
						if pageIdx != -1 {
							pageStr := urlPart[pageIdx+5:]
							pageStr = strings.Trim(pageStr, "><\" ")
							if ampIdx := strings.Index(pageStr, "&"); ampIdx != -1 {
								pageStr = pageStr[:ampIdx]
							}
							if num, parseErr := strconv.Atoi(pageStr); parseErr == nil {
								lastPage = num
							}
						}
					}
				}
			}

			return lastPage, nil
		}

		lastErr = runErr
		backoff := time.Duration(math.Pow(2, float64(attempt))) * initialBackoff
		time.Sleep(backoff)
	}
	return 0, fmt.Errorf("failed to get issue events after %d attempts: %w", maxRetries, lastErr)
}
