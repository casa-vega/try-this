# gh-github-stats

`gh-github-stats` is a [GitHub CLI](https://cli.github.com) extension that collects and reports comprehensive statistics about repositories in one or more organizations. Whether you're auditing your organization's repositories, preparing for migrations, or need detailed insights into repository health and activity, this extension provides the data you need.

## Features

- **Comprehensive Repository Statistics**: Collects detailed metrics for repositories including PRs, issues, releases, collaborators, and more
- **Package Information**: Gathers package counts and version information for each repository
- **Multi-Organization Support**: Process multiple organizations from a file or command line
- **Concurrent Processing**: Configurable worker threads for efficient API usage
- **Resume Capability**: Resume interrupted runs by skipping already processed repositories
- **Package Resume**: Resume package data collection using existing package CSV files
- **Real-time API Rate Limit Tracking**: Shows remaining API calls and reset time during processing
- **Verbose Output**: Detailed logging for debugging and monitoring
- **CSV Output**: Structured data output for analysis and reporting

## Install

```bash
gh extension install cvega/gh-github-stats
```

## Upgrade

```bash
gh extension upgrade gh-github-stats
```

## Usage

The tool provides a single `run` command that collects comprehensive statistics for repositories in one or more organizations.

```bash
Usage:
  github-stats run [flags]

Flags:
  -f, --fail-fast              Stop processing on first error
  -h, --help                   help for run
  -i, --input string           File with list of orgs to analyze
  -o, --org string             GitHub organization to analyze
  -O, --output string          Output file path for results (default "repo-stats.csv")
  -r, --resume                 Resume from existing output file, skipping already processed repositories
  -v, --verbose                Enable verbose output
  -w, --max-workers int        Maximum number of concurrent API calls (default 3)
```

## Examples

### Analyze a Single Organization

```bash
gh github-stats run \
  --org maintc
```

### Analyze Multiple Organizations from File

```bash
# Create a file with organization names (one per line)
echo "maintc" > orgs.txt
echo "another-org" >> orgs.txt

# Run analysis
gh github-stats run \
  --input orgs.txt
```

### Resume from Previous Run

If your analysis was interrupted (e.g., due to network issues), you can resume from where you left off:

```bash
# Resume processing, skipping already completed repositories
gh github-stats run \
  --org maintc \
  --resume
```

The tool will:
- Read the existing output file
- Skip repositories that have already been processed
- Read existing package data for each organization (stored in `{org}-packages.csv`)
- Skip package collection if data already exists
- Continue with remaining repositories
- Append new results to the existing file

**Package Data Storage**: Package information is stored separately in organization-specific files (e.g., `maintc-packages.csv`) to enable efficient resumption of package collection without re-fetching data.

### Custom Output File

```bash
gh github-stats run \
  --org maintc \
  --output custom-stats.csv
```

### Advanced Configuration

```bash
gh github-stats run \
  --input orgs.txt \
  --output multi-org-stats.csv \
  --max-workers 5 \
  --verbose \
  --fail-fast
```

## Input File Format

The input file should contain one organization name per line. Lines starting with `#` are treated as comments:

```
# Organizations to analyze
maintc
another-org
# third-org  # commented out
```

## Output Format

The tool generates a CSV file with the following columns that match the GraphQL query structure exactly (using camelCase field names):

| Column | Description |
|--------|-------------|
| org | Organization name |
| repo | Repository name |
| url | Repository URL |
| isFork | Whether the repository is a fork (TRUE/FALSE) |
| isArchived | Whether the repository is archived (TRUE/FALSE) |
| sizeMB | Repository size in megabytes |
| hasWiki | Whether the repository has a wiki (TRUE/FALSE) |
| createdAt | Repository creation date |
| updatedAt | Last update date |
| pushedAt | Last push date |
| collaborators | Number of collaborators |
| branches | Number of branches |
| tags | Number of tags |
| protectedBranches | Number of protected branches |
| issues | Number of issues |
| pullRequests | Number of pull requests |
| milestones | Number of milestones |
| releases | Number of releases |
| projects | Number of projects |
| discussions | Number of discussions |
| commitComments | Number of commit comments |
| packages | Number of packages in the repository |
| packageVersions | Total sum of package version counts for the repository |

### Package Data

For each organization, the tool also generates a separate CSV file (`{org}-packages.csv`) containing detailed package information:

| Column | Description |
|--------|-------------|
| org | Organization name |
| repo | Repository name (or "unassigned" for packages not associated with a repository) |
| packageName | Package name |
| packageType | Package type (npm, maven, container, etc.) |
| visibility | Package visibility (public/private) |
| createdAt | Package creation date |
| updatedAt | Last update date |
| versionCount | Number of versions (if available) |

**Note**: Some package types may not provide version count information through the GitHub API, so this field may be empty for certain packages.

## Performance

The tool uses parallel processing to efficiently collect data from multiple repositories:

- **Controlled Concurrency**: Limits concurrent API calls to avoid rate limiting
- **Progress Tracking**: Shows real-time progress during data collection
- **API Call Counting**: Tracks total API calls for monitoring

### Example Output

```
Processing organization: maintc
Found 25 repositories in maintc
✓ repo1
✓ repo2
⚠ repo3
✓ repo4
...
📊 Complete! Processed 25/25 repos | Total API calls: 156
```

## Required Permissions

The tool requires the following GitHub token permissions:

- **Repository access**: `repo` scope for private repositories
- **Organization access**: `read:org` for organization repositories
- **Package access**: `read:packages` for package statistics

## Requirements

- [GitHub CLI](https://cli.github.com) installed and authenticated
- Go 1.24.3 or later (for building from source)

## Building from Source

```bash
# Clone the repository
git clone https://github.com/cvega/gh-github-stats.git
cd gh-github-stats

# Build the extension
go build -o gh-github-stats

# Install as a GitHub CLI extension
gh extension install .
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Real-time API Monitoring

The tool provides monitoring of GitHub API usage at key points:

- **Initial Rate Limit**: Shows available API calls at the start
- **Progress Updates**: Displays rate limit status every 50 API calls during GraphQL operations (for large datasets)
- **Final Summary**: Shows rate limit status and total API calls used at the end

Example output:
```
INFO  Processing organization: maintc
INFO  API Usage: 19/15000 calls used | 14981 remaining | Reset: 21:24:52
SUCCESS  ✓ Complete! Processed 26/26 repos | Total API calls: 89
```
