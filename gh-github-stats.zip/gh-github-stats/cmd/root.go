package cmd

import (
	"fmt"

	"github.com/spf13/cobra"
)

var rootCmd = &cobra.Command{
	Use:   "gh-github-stats",
	Short: "Gather GitHub repository statistics for organizations",
	Long: `gh github-stats is a GitHub CLI extension that collects and reports 
statistics about repositories in one or more organizations.`,
	Run: func(cmd *cobra.Command, args []string) {
		// fallback message, stats logic is in a subcommand
		fmt.Println("Use `gh github-stats run` to start collecting statistics.")
	},
}

func Execute() {
	cobra.CheckErr(rootCmd.Execute())
}
