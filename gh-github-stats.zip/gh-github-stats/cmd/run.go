package main

import (
	"context"
	"os"
	"os/signal"
	"syscall"

	"github.com/cvega/gh-github-stats/internal/stats"
	"github.com/spf13/cobra"
)

var (
	inputFile  string
	orgName    string
	outputFile string
	maxWorkers int
	failFast   bool
	verbose    bool
	resume     bool
)

var runCmd = &cobra.Command{
	Use:   "run",
	Short: "Run repo statistics collection",
	Long: `Run repository statistics collection for one or more GitHub organizations.
	
The tool will:
1. Fetch all repositories in the specified organization(s)
2. Collect package counts for each repository
3. Output results to CSV format`,
	RunE: func(cmd *cobra.Command, args []string) error {
		// Set up context with cancellation
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()

		// Handle graceful shutdown
		sigChan := make(chan os.Signal, 1)
		signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
		go func() {
			<-sigChan
			cancel()
		}()

		// Run the statistics collection
		config := stats.Config{
			OrgName:    orgName,
			InputFile:  inputFile,
			OutputFile: outputFile,
			MaxWorkers: maxWorkers,
			FailFast:   failFast,
			Verbose:    verbose,
			Resume:     resume,
		}
		return stats.RunWithContext(ctx, config)
	},
}

func init() {
	rootCmd.AddCommand(runCmd)

	// Input options
	runCmd.Flags().StringVarP(&inputFile, "input", "i", "", "Input file with organization names (one per line)")
	runCmd.Flags().StringVarP(&orgName, "org", "o", "", "Single organization name to process")
	runCmd.MarkFlagsMutuallyExclusive("input", "org")
	runCmd.MarkFlagRequired("input")

	// Output options
	runCmd.Flags().StringVarP(&outputFile, "output", "f", "repo-stats.csv", "Output CSV file path")

	// Processing options
	runCmd.Flags().IntVarP(&maxWorkers, "workers", "w", 5, "Maximum number of concurrent workers")
	runCmd.Flags().BoolVarP(&failFast, "fail-fast", "F", false, "Stop processing on first error")
	runCmd.Flags().BoolVarP(&verbose, "verbose", "v", false, "Enable verbose output")
	runCmd.Flags().BoolVarP(&resume, "resume", "r", false, "Resume from last processed repository")
}
