package cmd

import (
	"context"
	"os"
	"os/signal"
	"syscall"

	"github.com/cvega/gh-github-stats/internal/stats"
	"github.com/spf13/cobra"
)

var (
	inputFile  string
	orgName    string
	outputFile string
	maxWorkers int
	failFast   bool
	verbose    bool
	resume     bool
)

var statsCmd = &cobra.Command{
	Use:   "run",
	Short: "Run repo statistics collection",
	Long: `Run repository statistics collection for one or more GitHub organizations.
	
The tool will:
1. Fetch all repositories in the specified organization(s)
2. Collect package counts for each repository
3. Gather detailed statistics for each repository
4. Output results to a CSV file

Examples:
  gh github-stats run --org maintc
  gh github-stats run --input orgs.txt --output results.csv
  gh github-stats run --org maintc --max-workers 5 --verbose
  gh github-stats run --org maintc --resume  # Resume from existing output file`,
	RunE: func(cmd *cobra.Command, args []string) error {
		config := stats.Config{
			OrgName:    orgName,
			InputFile:  inputFile,
			OutputFile: outputFile,
			MaxWorkers: maxWorkers,
			FailFast:   failFast,
			Verbose:    verbose,
			Resume:     resume,
		}

		// Set up context with signal handling
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()

		// Handle interrupt signals
		sigChan := make(chan os.Signal, 1)
		signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
		go func() {
			<-sigChan
			cancel()
		}()

		return stats.RunWithContext(ctx, config)
	},
}

// init registers the stats command and its flags.
func init() {
	rootCmd.AddCommand(statsCmd)

	statsCmd.Flags().StringVarP(&orgName, "org", "o", "", "GitHub organization to analyze")
	statsCmd.Flags().StringVarP(&inputFile, "input", "i", "", "File with list of orgs to analyze")
	statsCmd.Flags().StringVarP(&outputFile, "output", "O", "repo-stats.csv", "Output file path for results")
	statsCmd.Flags().IntVarP(&maxWorkers, "max-workers", "w", 3, "Maximum number of concurrent API calls")
	statsCmd.Flags().BoolVarP(&failFast, "fail-fast", "f", false, "Stop processing on first error")
	statsCmd.Flags().BoolVarP(&verbose, "verbose", "v", false, "Enable verbose output")
	statsCmd.Flags().BoolVarP(&resume, "resume", "r", false, "Resume from existing output file, skipping already processed repositories")
}
