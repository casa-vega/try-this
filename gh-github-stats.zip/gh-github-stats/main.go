package main

import (
	"github.com/cvega/gh-github-stats/cmd"
)

func main() {
	cmd.Execute()
}
